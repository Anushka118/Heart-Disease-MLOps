from docx import Document
from docx.shared import Inches, Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH

def create_report():
    document = Document()

    # Title Page
    document.add_heading('MLOps Project Report', 0)
    p = document.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = p.add_run('Heart Disease Classification Pipeline\n')
    run.bold = True
    run.font.size = Pt(16)
    p.add_run('\n\n\n\n')
    p.add_run('Course: MLOps (S1-25_AIMLCZG523)\n')
    p.add_run('Deliverable: Final End-to-End Pipeline Report\n\n')
    p.add_run('Submitted by: Aalekh\n')
    document.add_page_break()

    # Introduction
    document.add_heading('1. Project Overview', level=1)
    document.add_paragraph(
        "This project implements a robust, production-ready Machine Learning Operations (MLOps) pipeline "
        "designed for the classification of heart disease. The primary objective is to automate the entire "
        "lifecycle of the machine learning model, moving from raw data acquisition to scalable deployment "
        "in a Kubernetes environment."
    )
    document.add_paragraph(
        "The solution addresses key MLOps principles including reproducibility, automation, quality assurance, "
        "and observability. By leveraging tools like Docker, Kubernetes, GitHub Actions, and MLflow, the pipeline "
        "ensures that the model can be retrained, tested, and redeployed reliably without manual intervention."
    )

    # Project Structure
    document.add_heading('2. Repository Structure', level=1)
    document.add_paragraph("The project repository is organized as follows:")
    structure = (
        "├── app.py                 # Flask REST API for model serving\n"
        "├── Dockerfile             # Container definition for the API\n"
        "├── k8s_deployment.yaml    # Kubernetes Deployment manifest\n"
        "├── k8s_service.yaml       # Kubernetes Service manifest\n"
        "├── assignment.ipynb       # Main notebook for EDA and Training\n"
        "├── heart_disease_pipeline.pkl # Serialized Model Pipeline\n"
        "├── requirements.txt       # Python dependencies\n"
        "├── test/                  # Unit tests directory\n"
        "│   └── test_model.py      # Tests for data validity and model inference\n"
        "├── scripts/               # Utility scripts\n"
        "│   └── verify_setup.sh    # Script to verify environment setup\n"
        "└── .github/workflows/     # CI/CD definitions\n"
        "    └── mlops_pipeline.yml # Main workflow file"
    )
    document.add_paragraph(structure, style='Quote')

    # Setup Instructions
    document.add_heading('3. Setup and Installation', level=1)
    document.add_paragraph("The following steps detail how to set up the environment locally and deploy the solution.")
    
    document.add_heading('3.1 Prerequisites', level=2)
    p = document.add_paragraph(style='List Bullet')
    p.add_run('Python 3.9+')
    p = document.add_paragraph(style='List Bullet')
    p.add_run('Docker Desktop installed and running')
    p = document.add_paragraph(style='List Bullet')
    p.add_run('Kubernetes CLI (kubectl) & Minikube')

    document.add_heading('3.2 Local Installation', level=2)
    document.add_paragraph("1. Clone the repository and navigate to the directory.")
    document.add_paragraph("2. Install the required dependencies using pip:")
    document.add_paragraph("   pip install -r requirements.txt", style='Quote')
    document.add_paragraph("3. Run the verification script to ensure a clean environment:")
    document.add_paragraph("   bash scripts/verify_setup.sh", style='Quote')

    # EDA & Modeling
    document.add_heading('4. EDA and Modeling Choices', level=1)
    document.add_paragraph(
        "The core of the predictive capability lies in the analysis of the UCI Heart Disease dataset. "
        "We utilized the 'ucimlrepo' library to fetch data programmatically, ensuring pipeline reproducibility."
    )
    document.add_heading('4.1 Data Preprocessing', level=2)
    document.add_paragraph(
        "- Missing Value Imputation: Analysis of the 'ca' and 'thal' columns revealed missing entries, "
        "which were imputed using the mode (most frequent value) to preserve data distribution consistency.\n"
        "- Encoding: Categorical variables such as 'sex', 'cp', and 'trans' were One-Hot Encoded. This is crucial "
        "for preventing the model from inferring ordinal relationships where none exist."
    )
    document.add_heading('4.2 Model Selection', level=2)
    document.add_paragraph(
        "For the classification task, we employed a Scikit-learn Pipeline architecture. This approach encapsulates "
        "both the preprocessing steps (StandardScaler, OneHotEncoder) and the estimator into a single artifact. "
        "This ensures that the exact same transformations applied during training are applied during inference, "
        "eliminating training-serving skew."
    )

    # Experiment Tracking
    document.add_heading('5. Experiment Tracking', level=1)
    document.add_paragraph(
        "MLflow was integrated to track experiments. For every training run, the following are logged automatically:"
    )
    p = document.add_paragraph(style='List Bullet')
    p.add_run('Hyperparameters: Model configuration settings.')
    p = document.add_paragraph(style='List Bullet')
    p.add_run('Metrics: Accuracy, Precision, Recall, and F1-Score.')
    p = document.add_paragraph(style='List Bullet')
    p.add_run('Artifacts: The serialized model pickle file.')
    document.add_paragraph(
        "This tracking enables the team to compare different model versions and rollback to previous efficient versions if necessary."
    )

    # Architecture
    document.add_heading('6. System Architecture', level=1)
    document.add_paragraph(
        "The system follows a microservices architecture pattern where the model is deployed as an independent service."
    )
    document.add_paragraph("[Place Architecture Diagram Here]")
    document.add_paragraph(
        "The flow is as follows: Data -> Training -> MLflow Registry -> Docker Build -> Kubernetes Deployment -> LoadBalancer -> End User."
    )

    # CI/CD
    document.add_heading('7. CI/CD Pipeline', level=1)
    document.add_paragraph(
        "Automation is handled via GitHub Actions. The workflow is triggered on every push to the 'main' branch."
    )
    document.add_heading('7.1 Continuous Integration', level=2)
    document.add_paragraph(
        "- Linting: Code is checked with 'flake8' to enforce PEP8 standards.\n"
        "- Testing: Unit tests in 'test/test_model.py' are executed. These tests verify that the model artifact exists, "
        "loads correctly, and produces predictions of the expected shape (binary output)."
    )

    # Deployment
    document.add_heading('8. Containerization and Deployment', level=1)
    document.add_heading('8.1 Docker', level=2)
    document.add_paragraph(
        "The application is dockerized using a lightweight 'python:3.9-slim' base image. requirements are installed, "
        "and the Flask application is exposed on port 5000. This standardizes the runtime environment across development and production."
    )
    document.add_heading('8.2 Kubernetes', level=2)
    document.add_paragraph(
        "We utilize Kubernetes for orchestration. A 'Deployment' object manages the pod replicas, ensuring high availability. "
        "A 'Service' object of type 'LoadBalancer' exposes the application to the outside world. This setup was validated "
        "using a local Minikube cluster."
    )

    # Monitoring
    document.add_heading('9. Monitoring and Observability', level=1)
    document.add_paragraph(
        "The Flask API is instrumented with 'prometheus-flask-exporter'. This library automatically exposes a '/metrics' "
        "endpoint scraping standard HTTP metrics (latency, error rates). Additionally, custom counters track the specific "
        "number of prediction requests received."
    )

    # Conclusion
    document.add_heading('10. Conclusion', level=1)
    document.add_paragraph(
        "This project successfully demonstrates a complete MLOps lifecycle. By combining rigorous testing, "
        "containerization, and orchestration, we have built a system that is not only accurate but also robust "
        "and maintainable. The pipeline is ready for production use and can be easily scaled."
    )
    
    document.add_page_break()
    document.add_heading('Appendix: Screenshots', level=1)
    document.add_paragraph("[Paste Deployment Screenshots Here]")
    document.add_paragraph("[Paste CI/CD Workflow Screenshots Here]")

    document.save('Heart_Disease_MLOps_Report.docx')
    print("Report generated successfully: Heart_Disease_MLOps_Report.docx")

if __name__ == "__main__":
    create_report()
